# 🔧 QUICK FIX: Foreign Key Constraint Error

**Error you're seeing:**
```
Database error: insert or update on table "file_upload_history" 
violates foreign key constraint "file_upload_history_user_id_fkey"
```

---

## 🎯 **THE PROBLEM**

Your `file_upload_history` table requires `user_id` and `organization` to be NOT NULL, but the backend is trying to insert a user_id that doesn't exist in the `users` table.

---

## ✅ **SOLUTION (2 OPTIONS)**

### **OPTION 1: Make Fields Nullable (RECOMMENDED for testing)**

This allows file uploads without requiring authentication.

**Run this in Supabase SQL Editor:**

```sql
-- Make user_id and organization nullable
ALTER TABLE file_upload_history 
ALTER COLUMN user_id DROP NOT NULL;

ALTER TABLE file_upload_history 
ALTER COLUMN organization DROP NOT NULL;

-- Also do the same for pv_cases
ALTER TABLE pv_cases 
ALTER COLUMN user_id DROP NOT NULL;

ALTER TABLE pv_cases 
ALTER COLUMN organization DROP NOT NULL;

-- Verify
SELECT 
    column_name,
    is_nullable
FROM information_schema.columns
WHERE table_schema = 'public' 
  AND table_name IN ('file_upload_history', 'pv_cases')
  AND column_name IN ('user_id', 'organization')
ORDER BY table_name, column_name;

-- Expected: All should be 'YES'
```

---

### **OPTION 2: Create a System User**

Create a default user for system uploads.

```sql
-- Create a system user
INSERT INTO users (id, email, name)
VALUES (
    '00000000-0000-0000-0000-000000000000',
    'system@aethersignal.com',
    'System User'
)
ON CONFLICT (id) DO NOTHING;

-- Verify
SELECT * FROM users WHERE id = '00000000-0000-0000-0000-000000000000';
```

---

## 🚀 **AFTER FIXING DATABASE**

1. **Replace backend file:**

```bash
cd backend
cp /path/to/files_FIXED.py app/api/files.py
```

2. **Restart backend:**

```bash
python app/main.py
```

3. **Test upload again!**

---

## 📋 **WHAT THE FIXED CODE DOES**

The new `files_FIXED.py`:

1. ✅ Tries to get a real user_id from database
2. ✅ If no users exist, uses NULL instead
3. ✅ Only adds user_id/organization to record if they exist
4. ✅ Gracefully handles missing authentication
5. ✅ Better error messages

---

## 🧪 **TEST IT**

```bash
# Create a test file
echo "Patient: John Doe
Age: 45
Drug: Aspirin 100mg
Reaction: Stomach pain" > test.txt

# Upload via frontend
# Visit: http://localhost:3001/signals
# Click "Upload Data"
# Select test.txt
```

**Expected:**
- ✅ Upload succeeds
- ✅ Processing starts
- ✅ Cases created
- ✅ No foreign key errors!

---

## 💡 **WHICH OPTION?**

**For testing/development:** Use Option 1 (nullable fields)
- ✅ Simpler
- ✅ No authentication needed
- ✅ Can add auth later

**For production:** Use Option 2 (system user) + proper auth
- ✅ Better data integrity
- ✅ Proper user tracking
- ✅ Ready for multi-user

---

## 📥 **FILES YOU NEED**

- [files_FIXED.py](computer:///mnt/user-data/outputs/week5-migration/files_FIXED.py)
- [FIX_NULLABLE_FIELDS.sql](computer:///mnt/user-data/outputs/week5-migration/FIX_NULLABLE_FIELDS.sql)

---

## 🎯 **DO THIS NOW**

1. **Run Option 1 SQL** (make fields nullable)
2. **Copy files_FIXED.py** to backend
3. **Restart backend**
4. **Test upload**
5. **Report success!**

---

**This will fix the error in 5 minutes!** 🚀
