-- ============================================================================
-- QUICK FIX: Make user_id and organization nullable in file_upload_history
-- ============================================================================
-- This allows file uploads without requiring a valid user_id
-- Useful for testing and initial development

-- Make user_id nullable (remove NOT NULL constraint)
ALTER TABLE file_upload_history 
ALTER COLUMN user_id DROP NOT NULL;

-- Make organization nullable (remove NOT NULL constraint)
ALTER TABLE file_upload_history 
ALTER COLUMN organization DROP NOT NULL;

-- Verify changes
SELECT 
    column_name,
    data_type,
    is_nullable
FROM information_schema.columns
WHERE table_schema = 'public' 
  AND table_name = 'file_upload_history'
  AND column_name IN ('user_id', 'organization')
ORDER BY column_name;

-- Expected output:
-- user_id     | uuid | YES
-- organization| text | YES

COMMENT ON COLUMN file_upload_history.user_id IS 'User ID (nullable for system uploads)';
COMMENT ON COLUMN file_upload_history.organization IS 'Organization (nullable for system uploads)';
