from fastapi import APIRouter, UploadFile, File, HTTPException, BackgroundTasks
from typing import Optional, List
from pydantic import BaseModel
from datetime import datetime
import os
import hashlib
import uuid
from pathlib import Path
import asyncio
import json
from supabase import create_client, Client

router = APIRouter(prefix="/api/v1/files", tags=["files"])

# Initialize Supabase client (prefer SERVICE_KEY for write access, fallback to ANON_KEY)
supabase_url = os.getenv("SUPABASE_URL")
supabase_key = os.getenv("SUPABASE_SERVICE_KEY") or os.getenv("SUPABASE_ANON_KEY")

if not supabase_url or not supabase_key:
    raise ValueError("SUPABASE_URL and SUPABASE_SERVICE_KEY (or SUPABASE_ANON_KEY) must be set in environment variables")

supabase: Client = create_client(supabase_url, supabase_key)

# Initialize Anthropic client (optional - will fail gracefully if not set)
anthropic_client = None
try:
    anthropic_api_key = os.getenv("ANTHROPIC_API_KEY")
    if anthropic_api_key:
        import anthropic
        anthropic_client = anthropic.Anthropic(api_key=anthropic_api_key)
except Exception as e:
    print(f"Warning: Anthropic client not initialized: {e}")

# Create uploads directory if it doesn't exist
UPLOADS_DIR = Path("uploads")
UPLOADS_DIR.mkdir(exist_ok=True)

# Supported file formats
SUPPORTED_FORMATS = {
    'pdf': ['.pdf'],
    'document': ['.doc', '.docx', '.txt', '.rtf'],
    'spreadsheet': ['.xls', '.xlsx', '.csv'],
    'email': ['.eml', '.msg'],
    'image': ['.jpg', '.jpeg', '.png', '.gif', '.bmp'],
    'audio': ['.mp3', '.wav', '.m4a'],
    'archive': ['.zip', '.rar', '.7z'],
    'xml': ['.xml'],
}


class FileUploadResponse(BaseModel):
    file_id: str
    filename: str
    file_size: int
    status: str
    message: str


class FileStatusResponse(BaseModel):
    file_id: str
    filename: str
    status: str
    progress: Optional[int] = None
    message: Optional[str] = None
    cases_created: Optional[int] = None
    error: Optional[str] = None


def get_default_user_id() -> str:
    """
    Get a valid user_id from the users table, or None if no users exist
    This prevents foreign key constraint violations
    """
    try:
        # Try to get the first user from the users table
        result = supabase.table("users").select("id").limit(1).execute()
        if result.data and len(result.data) > 0:
            return result.data[0]["id"]
        return None
    except Exception as e:
        print(f"Warning: Could not fetch user_id: {e}")
        return None


def calculate_file_hash(file_path: Path) -> str:
    """Calculate MD5 hash of file"""
    hash_md5 = hashlib.md5()
    with open(file_path, "rb") as f:
        for chunk in iter(lambda: f.read(4096), b""):
            hash_md5.update(chunk)
    return hash_md5.hexdigest()


def detect_file_type(filename: str) -> str:
    """Detect file type from extension and return category"""
    ext = Path(filename).suffix.lower()
    
    # Map to category format used by AI processing
    for category, extensions in SUPPORTED_FORMATS.items():
        if ext in extensions:
            return category
    
    return "unknown"


async def extract_content(file_path: str, file_type: str) -> str:
    """
    Extract text content from different file types
    """
    try:
        if file_type == "pdf":
            import pdfplumber
            text = ""
            with pdfplumber.open(file_path) as pdf:
                for page in pdf.pages:
                    text += page.extract_text() or ""
            return text
        
        elif file_type == "document":
            # Try Word document first
            if file_path.endswith('.docx'):
                from docx import Document
                doc = Document(file_path)
                text = "\n".join([para.text for para in doc.paragraphs])
                return text
            else:
                # Plain text
                with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
                    return f.read()
        
        elif file_type == "spreadsheet":
            import pandas as pd
            df = pd.read_excel(file_path)
            text = df.to_string()
            return text
        
        elif file_type == "email":
            import email
            with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
                msg = email.message_from_file(f)
                text = f"From: {msg['from']}\nSubject: {msg['subject']}\n\n{msg.get_payload()}"
                return text
        
        elif file_type == "image":
            # OCR for images
            try:
                import pytesseract
                from PIL import Image
                img = Image.open(file_path)
                text = pytesseract.image_to_string(img)
                return text
            except Exception as e:
                print(f"OCR error: {e}")
                return f"[Image file - OCR not available: {e}]"
        
        else:
            # Fallback: try reading as text
            with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
                return f.read()
    
    except Exception as e:
        print(f"Content extraction error: {e}")
        return f"[Error extracting content: {str(e)}]"


async def extract_entities_with_ai(content: str) -> List[dict]:
    """
    Use Claude to extract pharmacovigilance entities from text
    """
    
    if not anthropic_client:
        print("Warning: Anthropic client not initialized, returning mock data")
        # Return mock entity for testing
        return [{
            "patient": {"age": None, "sex": "Unknown"},
            "drug": {"name": "Unknown Drug", "dose": None},
            "reaction": {"description": "Test reaction", "severity": "unknown"},
            "serious": False,
            "confidence": 0.5,
            "narrative": "Test case created from file without AI processing"
        }]
    
    # Limit content to first 10K chars to avoid token limits
    content = content[:10000]
    
    prompt = f"""
You are a pharmacovigilance expert. Extract adverse event case information from the following text.

Text:
{content}

Extract the following information for each adverse event case found:
- Patient demographics (age, sex)
- Drug information (name, dose, route, frequency)
- Adverse reactions (description, onset, severity, outcome)
- Seriousness (is it a serious adverse event?)

Return ONLY a JSON array of cases. Each case should have this structure:
{{
  "patient": {{
    "age": "number or null",
    "sex": "M/F/Unknown"
  }},
  "drug": {{
    "name": "drug name",
    "dose": "dose string or null"
  }},
  "reaction": {{
    "description": "reaction description",
    "severity": "mild/moderate/severe/unknown"
  }},
  "serious": true/false,
  "confidence": 0.85,
  "narrative": "brief case narrative in past tense"
}}

If no adverse events found, return empty array [].
"""
    
    try:
        message = anthropic_client.messages.create(
            model="claude-sonnet-4-20250514",
            max_tokens=4000,
            messages=[
                {"role": "user", "content": prompt}
            ]
        )
        
        # Parse JSON response
        response_text = message.content[0].text
        
        # Extract JSON from response (handle markdown code blocks)
        if "```json" in response_text:
            json_str = response_text.split("```json")[1].split("```")[0].strip()
        elif "```" in response_text:
            json_str = response_text.split("```")[1].split("```")[0].strip()
        else:
            json_str = response_text.strip()
        
        entities = json.loads(json_str)
        
        return entities if isinstance(entities, list) else [entities]
    
    except Exception as e:
        print(f"AI extraction error: {e}")
        return []


async def create_cases_from_entities(entities: List[dict], file_id: str, user_id: str = None, organization: str = None) -> List[str]:
    """
    Create pv_cases records from extracted entities
    """
    
    case_ids = []
    
    for entity in entities:
        try:
            case_data = {
                "drug_name": entity.get("drug", {}).get("name", "Unknown"),
                "reaction": entity.get("reaction", {}).get("description", "Unknown"),
                "age": entity.get("patient", {}).get("age"),
                "sex": entity.get("patient", {}).get("sex"),
                "serious": entity.get("serious", False),
                "source": "AI_EXTRACTED",
                "source_file_id": file_id,
                "narrative": entity.get("narrative", ""),
                "ai_extracted": True,
                "ai_confidence": entity.get("confidence", 0.5),
            }
            
            # Only add user_id and organization if they exist (to avoid FK constraint violations)
            if user_id:
                case_data["user_id"] = user_id
            if organization:
                case_data["organization"] = organization
            
            result = supabase.table("pv_cases").insert(case_data).execute()
            
            if result.data:
                case_ids.append(result.data[0]["id"])
        
        except Exception as e:
            print(f"Error creating case: {e}")
            continue
    
    return case_ids


async def auto_code_cases(case_ids: List[str]):
    """
    Auto-code cases with MedDRA terms using AI (placeholder)
    """
    # Future: Implement MedDRA coding
    pass


async def process_file_ai(file_id: str, file_path: Path, filename: str, user_id: str = None, organization: str = None):
    """
    Background task to process file with AI
    """
    try:
        # Update status to processing
        supabase.table("file_upload_history").update({
            "upload_status": "processing",
            "progress": 10,
            "status_message": "Extracting content...",
            "processing_started_at": datetime.now().isoformat()
        }).eq("id", file_id).execute()

        # Step 1: Extract content based on file type
        file_ext = Path(filename).suffix.lower()
        file_type = detect_file_type(filename)
        
        content = await extract_content(str(file_path), file_type)
        
        if not content or len(content.strip()) == 0:
            raise Exception("No content extracted from file")
        
        supabase.table("file_upload_history").update({
            "progress": 30,
            "status_message": "AI extracting entities..."
        }).eq("id", file_id).execute()
        
        # Step 2: AI entity extraction
        entities = await extract_entities_with_ai(content)
        
        supabase.table("file_upload_history").update({
            "progress": 60,
            "status_message": "Creating cases..."
        }).eq("id", file_id).execute()
        
        # Step 3: Create cases
        cases_created = await create_cases_from_entities(entities, file_id, user_id, organization)
        
        supabase.table("file_upload_history").update({
            "progress": 90,
            "status_message": "Auto-coding..."
        }).eq("id", file_id).execute()
        
        # Step 4: Auto-code cases (placeholder)
        await auto_code_cases(cases_created)
        
        # Calculate confidence score (average of all case confidences)
        avg_confidence = None
        if cases_created:
            confidences = []
            for case_id in cases_created:
                case_result = supabase.table("pv_cases").select("ai_confidence").eq("id", case_id).execute()
                if case_result.data and case_result.data[0].get("ai_confidence"):
                    confidences.append(float(case_result.data[0]["ai_confidence"]))
            
            if confidences:
                avg_confidence = sum(confidences) / len(confidences)
        
        # Mark as completed
        supabase.table("file_upload_history").update({
            "upload_status": "completed",
            "progress": 100,
            "status_message": f"Successfully processed. {len(cases_created)} case(s) created.",
            "cases_created": len(cases_created),
            "total_cases": len(cases_created),
            "ai_confidence_score": avg_confidence,
            "processing_completed_at": datetime.now().isoformat(),
        }).eq("id", file_id).execute()
        
    except Exception as e:
        # Mark as failed
        print(f"Processing error: {e}")
        supabase.table("file_upload_history").update({
            "upload_status": "failed",
            "processing_error": str(e),
            "status_message": f"Processing failed: {str(e)}",
            "processing_completed_at": datetime.now().isoformat(),
        }).eq("id", file_id).execute()


@router.post("/upload", response_model=FileUploadResponse)
async def upload_file(
    background_tasks: BackgroundTasks,
    file: UploadFile = File(...),
    user_id: Optional[str] = None,
    organization: Optional[str] = None,
):
    """
    Upload a file for AI processing
    Supports: PDF, Word, Excel, Email, Images, Audio, ZIP, etc.
    """
    try:
        # Validate file
        if not file.filename:
            raise HTTPException(status_code=400, detail="No filename provided")
        
        # Generate upload ID
        file_id = str(uuid.uuid4())

        # Get file extension and detect type
        file_ext = Path(file.filename).suffix.lower()
        file_type = detect_file_type(file.filename)
        
        if file_type == "unknown":
            raise HTTPException(
                status_code=400,
                detail=f"Unsupported file format: {file_ext}. Supported: PDF, Word, Excel, Email, Images, Audio, ZIP"
            )

        # Save file to disk
        file_path = UPLOADS_DIR / f"{file_id}{file_ext}"
        with open(file_path, "wb") as f:
            content = await file.read()
            f.write(content)

        # Calculate file hash
        file_hash = calculate_file_hash(file_path)

        # Get file size
        file_size = file_path.stat().st_size

        # Get a valid user_id if not provided
        if not user_id:
            user_id = get_default_user_id()
        
        # If we still don't have a user_id, we cannot insert (FK constraint)
        # So we'll need to handle this gracefully
        if not user_id:
            # Try to get from organization or use system user
            org_to_use = organization or "system"
        else:
            org_to_use = organization or "default"

        # Create database record
        record = {
            "id": file_id,
            "filename": file.filename,
            "file_size_bytes": file_size,
            "file_hash_md5": file_hash,
            "file_type": file_type,
            "file_path": str(file_path),
            "source": "upload",
            "upload_status": "queued",
            "progress": 0,
            "status_message": "File uploaded, queued for processing...",
            "uploaded_at": datetime.now().isoformat(),
        }
        
        # Only add user_id and organization if user_id exists
        if user_id:
            record["user_id"] = user_id
            record["organization"] = org_to_use

        try:
            supabase.table("file_upload_history").insert(record).execute()
        except Exception as db_error:
            # If insert fails, clean up file and raise error
            file_path.unlink()
            print(f"Database error: {db_error}")
            raise HTTPException(status_code=500, detail=f"Database error: {str(db_error)}")

        # Start background processing
        background_tasks.add_task(process_file_ai, file_id, file_path, file.filename, user_id, org_to_use)

        return FileUploadResponse(
            file_id=file_id,
            filename=file.filename,
            file_size=file_size,
            status="queued",
            message="File uploaded successfully. Processing started."
        )

    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error uploading file: {str(e)}")


@router.get("/status/{file_id}", response_model=FileStatusResponse)
async def get_file_status(file_id: str):
    """Get processing status of uploaded file"""
    try:
        result = supabase.table("file_upload_history").select("*").eq("id", file_id).execute()

        if not result.data or len(result.data) == 0:
            raise HTTPException(status_code=404, detail="Upload not found")

        file_data = result.data[0]

        # Get progress and status
        progress = file_data.get("progress", 0)
        status = file_data.get("upload_status", "unknown")
        
        # Ensure progress is set based on status if not explicitly set
        if status == "queued" and progress == 0:
            progress = 10
        elif status == "processing" and progress == 0:
            progress = 50
        elif status == "completed":
            progress = 100
        elif status == "failed":
            progress = 0

        return FileStatusResponse(
            file_id=file_id,
            filename=file_data.get("filename", "unknown"),
            status=status,
            progress=progress,
            message=file_data.get("status_message", ""),
            cases_created=file_data.get("cases_created"),
            error=file_data.get("processing_error")
        )

    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error fetching status: {str(e)}")
