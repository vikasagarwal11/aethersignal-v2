from fastapi import APIRouter, Query
from typing import Optional, List
from pydantic import BaseModel
from datetime import datetime
import os
from supabase import create_client, Client

router = APIRouter(prefix="/api/v1/signals", tags=["signals"])

# Initialize Supabase client
supabase_url = os.getenv("SUPABASE_URL")
supabase_key = os.getenv("SUPABASE_SERVICE_KEY")
supabase: Client = create_client(supabase_url, supabase_key)


class Signal(BaseModel):
    id: int
    drug_name: str
    reaction: str
    prr: float
    case_count: int
    priority: str
    serious: bool
    event_date: Optional[str]
    organization_id: Optional[str]


class SignalsResponse(BaseModel):
    signals: List[Signal]
    total: int
    page: int
    page_size: int


@router.get("/", response_model=SignalsResponse)
async def get_signals(
    search: Optional[str] = Query(None, description="Search drug or reaction"),
    priority: Optional[List[str]] = Query(None, description="Filter by priority"),
    serious: Optional[bool] = Query(None, description="Filter by serious events"),
    dataset: Optional[str] = Query("faers", description="Dataset type"),
    page: int = Query(1, ge=1, description="Page number"),
    page_size: int = Query(50, ge=1, le=1000, description="Items per page"),
):
    """
    Get signals with filtering, search, and pagination
    """
    
    # Start query
    query = supabase.table("pv_cases").select("*", count="exact")
    
    # Apply filters
    if search:
        # Search in drug_name or reaction
        query = query.or_(f"drug_name.ilike.%{search}%,reaction.ilike.%{search}%")
    
    if priority:
        query = query.in_("priority", priority)
    
    if serious is not None:
        query = query.eq("serious", serious)
    
    if dataset:
        query = query.eq("dataset", dataset)
    
    # Get total count
    count_response = query.execute()
    total = len(count_response.data) if count_response.data else 0
    
    # Apply pagination
    start = (page - 1) * page_size
    end = start + page_size - 1
    query = query.range(start, end)
    
    # Order by PRR descending (highest risk first)
    query = query.order("prr", desc=True)
    
    # Execute query
    response = query.execute()
    
    # Transform data
    signals = []
    for row in response.data:
        signals.append(Signal(
            id=row.get("id"),
            drug_name=row.get("drug_name", "Unknown"),
            reaction=row.get("reaction", "Unknown"),
            prr=float(row.get("prr", 0)),
            case_count=int(row.get("case_count", 0)),
            priority=row.get("priority", "low"),
            serious=bool(row.get("serious", False)),
            event_date=row.get("event_date"),
            organization_id=row.get("organization_id"),
        ))
    
    return SignalsResponse(
        signals=signals,
        total=total,
        page=page,
        page_size=page_size,
    )


@router.get("/stats")
async def get_signal_stats():
    """
    Get summary statistics for signals
    """
    
    # Get total cases
    total_response = supabase.table("pv_cases").select("id", count="exact").execute()
    total_cases = len(total_response.data) if total_response.data else 0
    
    # Get critical signals
    critical_response = supabase.table("pv_cases").select("id", count="exact").eq("priority", "critical").execute()
    critical_count = len(critical_response.data) if critical_response.data else 0
    
    # Get serious events
    serious_response = supabase.table("pv_cases").select("id", count="exact").eq("serious", True).execute()
    serious_count = len(serious_response.data) if serious_response.data else 0
    
    return {
        "total_cases": total_cases,
        "critical_signals": critical_count,
        "serious_events": serious_count,
        "datasets": ["faers", "e2b", "social"],
    }
