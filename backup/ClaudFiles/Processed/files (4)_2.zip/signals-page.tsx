"use client";

import { useState, useEffect } from "react";
import { DataTable, Column } from "@/components/ui/data-table";
import { Input } from "@/components/ui/input";
import { Checkbox } from "@/components/ui/checkbox";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { KPICard } from "@/components/ui/kpi-card";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Separator } from "@/components/ui/separator";
import { Skeleton } from "@/components/ui/skeleton";
import { toast, toastSuccess, toastError } from "@/components/ui/toast";
import { Search, Download, FileText, TrendingUp, AlertTriangle, Activity } from "lucide-react";

interface Signal {
  id: number;
  drug_name: string;
  reaction: string;
  prr: number;
  case_count: number;
  priority: string;
  serious: boolean;
  event_date?: string;
}

interface Stats {
  total_cases: number;
  critical_signals: number;
  serious_events: number;
}

export default function SignalExplorerPage() {
  const [signals, setSignals] = useState<Signal[]>([]);
  const [stats, setStats] = useState<Stats | null>(null);
  const [loading, setLoading] = useState(true);
  const [selectedSignals, setSelectedSignals] = useState<Signal[]>([]);
  
  // Filters
  const [search, setSearch] = useState("");
  const [dataset, setDataset] = useState("faers");
  const [priorityFilters, setPriorityFilters] = useState({
    critical: true,
    high: true,
    medium: true,
    low: false,
  });
  const [seriousFilter, setSeriousFilter] = useState<boolean | null>(null);
  
  // Pagination
  const [page, setPage] = useState(1);
  const [total, setTotal] = useState(0);

  // Fetch signals
  const fetchSignals = async () => {
    try {
      setLoading(true);
      
      // Build query params
      const params = new URLSearchParams({
        page: page.toString(),
        page_size: "50",
        dataset,
      });
      
      if (search) params.append("search", search);
      
      // Add priority filters
      Object.entries(priorityFilters).forEach(([priority, enabled]) => {
        if (enabled) params.append("priority", priority);
      });
      
      if (seriousFilter !== null) {
        params.append("serious", seriousFilter.toString());
      }
      
      const response = await fetch(
        `http://localhost:8000/api/v1/signals?${params}`
      );
      
      if (!response.ok) throw new Error("Failed to fetch signals");
      
      const data = await response.json();
      setSignals(data.signals);
      setTotal(data.total);
      
    } catch (error) {
      console.error("Error fetching signals:", error);
      toastError("Error", "Failed to load signals");
    } finally {
      setLoading(false);
    }
  };

  // Fetch stats
  const fetchStats = async () => {
    try {
      const response = await fetch("http://localhost:8000/api/v1/signals/stats");
      if (!response.ok) throw new Error("Failed to fetch stats");
      const data = await response.json();
      setStats(data);
    } catch (error) {
      console.error("Error fetching stats:", error);
    }
  };

  // Initial load
  useEffect(() => {
    fetchSignals();
    fetchStats();
  }, []);

  // Refetch when filters change
  useEffect(() => {
    const debounce = setTimeout(() => {
      setPage(1); // Reset to page 1
      fetchSignals();
    }, 500);
    
    return () => clearTimeout(debounce);
  }, [search, dataset, priorityFilters, seriousFilter]);

  // Export to CSV
  const exportToCSV = () => {
    if (selectedSignals.length === 0) {
      toastError("No Selection", "Please select signals to export");
      return;
    }

    const headers = ["Drug", "Reaction", "PRR", "Cases", "Priority", "Serious"];
    const rows = selectedSignals.map(s => [
      s.drug_name,
      s.reaction,
      s.prr,
      s.case_count,
      s.priority,
      s.serious ? "Yes" : "No",
    ]);

    const csv = [
      headers.join(","),
      ...rows.map(row => row.join(",")),
    ].join("\n");

    const blob = new Blob([csv], { type: "text/csv" });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `signals-export-${new Date().toISOString().split("T")[0]}.csv`;
    a.click();

    toastSuccess("Exported!", `${selectedSignals.length} signals exported to CSV`);
  };

  // Define table columns
  const columns: Column<Signal>[] = [
    {
      id: "drug_name",
      header: "Drug",
      accessor: (row) => row.drug_name,
      sortable: true,
      width: 200,
    },
    {
      id: "reaction",
      header: "Reaction",
      accessor: (row) => row.reaction,
      sortable: true,
      width: 250,
    },
    {
      id: "prr",
      header: "PRR",
      accessor: (row) => (
        <span className={row.prr > 10 ? "text-danger-500 font-semibold" : ""}>
          {row.prr.toFixed(1)}
        </span>
      ),
      sortable: true,
      width: 100,
      align: "right",
    },
    {
      id: "case_count",
      header: "Cases",
      accessor: (row) => row.case_count.toLocaleString(),
      sortable: true,
      width: 120,
      align: "right",
    },
    {
      id: "priority",
      header: "Priority",
      accessor: (row) => (
        <Badge
          variant={
            row.priority === "critical" ? "danger" :
            row.priority === "high" ? "warning" :
            row.priority === "medium" ? "default" : "secondary"
          }
          size="sm"
        >
          {row.priority}
        </Badge>
      ),
      sortable: true,
      width: 120,
    },
    {
      id: "serious",
      header: "Serious",
      accessor: (row) => (
        row.serious ? (
          <Badge variant="danger" size="sm">Yes</Badge>
        ) : (
          <Badge variant="secondary" size="sm">No</Badge>
        )
      ),
      width: 100,
      align: "center",
    },
  ];

  return (
    <div className="min-h-screen bg-gray-900">
      {/* Header */}
      <div className="border-b border-gray-800 bg-gray-900/50 backdrop-blur">
        <div className="container mx-auto px-6 py-4">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-2xl font-bold text-white">Signal Explorer</h1>
              <p className="text-sm text-gray-400 mt-1">
                Pharmacovigilance signal detection and analysis
              </p>
            </div>
            <div className="flex items-center gap-2">
              <Button
                variant="ghost"
                size="sm"
                onClick={exportToCSV}
                disabled={selectedSignals.length === 0}
              >
                <Download className="h-4 w-4 mr-2" />
                Export ({selectedSignals.length})
              </Button>
              <Button variant="primary" size="sm">
                <FileText className="h-4 w-4 mr-2" />
                Generate Report
              </Button>
            </div>
          </div>
        </div>
      </div>

      <div className="container mx-auto px-6 py-6">
        {/* KPI Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
          {stats ? (
            <>
              <KPICard
                title="Total Cases"
                value={stats.total_cases}
                icon={<Activity className="h-5 w-5" />}
                trend="up"
                change={12}
                description="vs last month"
              />
              <KPICard
                title="Critical Signals"
                value={stats.critical_signals}
                icon={<AlertTriangle className="h-5 w-5" />}
                trend="up"
                change={5}
              />
              <KPICard
                title="Serious Events"
                value={stats.serious_events}
                icon={<TrendingUp className="h-5 w-5" />}
                trend="down"
                change={-3}
              />
            </>
          ) : (
            <>
              <Skeleton className="h-32" />
              <Skeleton className="h-32" />
              <Skeleton className="h-32" />
            </>
          )}
        </div>

        <div className="grid grid-cols-12 gap-6">
          {/* Filters Sidebar */}
          <div className="col-span-12 lg:col-span-3">
            <Card>
              <CardHeader>
                <CardTitle className="text-base">Filters</CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                {/* Dataset */}
                <div>
                  <label className="text-sm font-medium text-gray-200 mb-2 block">
                    Dataset
                  </label>
                  <Select value={dataset} onValueChange={setDataset}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="faers">FAERS 2024</SelectItem>
                      <SelectItem value="e2b">E2B Reports</SelectItem>
                      <SelectItem value="social">Social Media</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <Separator />

                {/* Priority */}
                <div>
                  <label className="text-sm font-medium text-gray-200 mb-3 block">
                    Priority
                  </label>
                  <div className="space-y-3">
                    <Checkbox
                      label="Critical"
                      checked={priorityFilters.critical}
                      onCheckedChange={(checked) =>
                        setPriorityFilters({ ...priorityFilters, critical: !!checked })
                      }
                    />
                    <Checkbox
                      label="High"
                      checked={priorityFilters.high}
                      onCheckedChange={(checked) =>
                        setPriorityFilters({ ...priorityFilters, high: !!checked })
                      }
                    />
                    <Checkbox
                      label="Medium"
                      checked={priorityFilters.medium}
                      onCheckedChange={(checked) =>
                        setPriorityFilters({ ...priorityFilters, medium: !!checked })
                      }
                    />
                    <Checkbox
                      label="Low"
                      checked={priorityFilters.low}
                      onCheckedChange={(checked) =>
                        setPriorityFilters({ ...priorityFilters, low: !!checked })
                      }
                    />
                  </div>
                </div>

                <Separator />

                {/* Serious Events */}
                <div>
                  <label className="text-sm font-medium text-gray-200 mb-3 block">
                    Serious Events
                  </label>
                  <div className="space-y-3">
                    <Checkbox
                      label="Serious only"
                      checked={seriousFilter === true}
                      onCheckedChange={(checked) =>
                        setSeriousFilter(checked ? true : null)
                      }
                    />
                    <Checkbox
                      label="Non-serious only"
                      checked={seriousFilter === false}
                      onCheckedChange={(checked) =>
                        setSeriousFilter(checked ? false : null)
                      }
                    />
                  </div>
                </div>

                <Separator />

                {/* Clear Filters */}
                <Button
                  variant="ghost"
                  size="sm"
                  className="w-full"
                  onClick={() => {
                    setSearch("");
                    setDataset("faers");
                    setPriorityFilters({
                      critical: true,
                      high: true,
                      medium: true,
                      low: false,
                    });
                    setSeriousFilter(null);
                  }}
                >
                  Clear All Filters
                </Button>
              </CardContent>
            </Card>
          </div>

          {/* Main Content */}
          <div className="col-span-12 lg:col-span-9">
            <Card>
              <CardHeader>
                <div className="flex items-center justify-between">
                  <CardTitle>
                    Signals ({total.toLocaleString()})
                  </CardTitle>
                  <Input
                    type="search"
                    placeholder="Search drug or reaction..."
                    value={search}
                    onChange={(e) => setSearch(e.target.value)}
                    leftIcon={<Search className="h-4 w-4" />}
                    className="max-w-xs"
                  />
                </div>
              </CardHeader>
              <CardContent>
                {loading ? (
                  <div className="space-y-2">
                    <Skeleton className="h-12 w-full" />
                    <Skeleton className="h-12 w-full" />
                    <Skeleton className="h-12 w-full" />
                  </div>
                ) : (
                  <DataTable
                    data={signals}
                    columns={columns}
                    enableSelection
                    enableSorting
                    enableFiltering={false} // Using external filters
                    virtualScrolling
                    maxHeight="600px"
                    onSelectionChange={setSelectedSignals}
                    emptyMessage="No signals found. Try adjusting your filters."
                  />
                )}
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}
