# 🚀 Week 3: Signal Explorer - Installation Guide

**Building your first real, working screen with database integration!**

---

## 🎯 **WHAT WE'RE BUILDING**

**Signal Explorer** - Your main pharmacovigilance workflow screen:
- ✅ Search signals (drug name, reaction)
- ✅ Filter by priority, serious events, dataset
- ✅ Sort and select signals
- ✅ Real data from Supabase database
- ✅ Export to CSV
- ✅ Professional UI with KPI cards

---

## 📦 **FILES TO INSTALL**

You need to install **3 files:**

1. **Backend API** - `signals.py` (new file)
2. **Updated main.py** - `main.py` (replace existing)
3. **Frontend page** - `signals-page.tsx` (new file)

---

## 🔧 **STEP 1: INSTALL BACKEND**

### **1A: Create API Directory**

```bash
# From backend directory
cd backend

# Create api directory if it doesn't exist
mkdir -p app/api

# Create __init__.py
touch app/api/__init__.py
```

### **1B: Copy signals.py**

Copy `signals.py` to `backend/app/api/signals.py`

**This file:**
- Creates `/api/v1/signals` endpoint
- Fetches data from your `pv_cases` table
- Supports search, filtering, pagination
- Returns JSON data for frontend

### **1C: Update main.py**

Replace `backend/app/main.py` with the new `main.py`

**Changes:**
- Imports signals router
- Registers `/api/v1/signals` endpoints

### **1D: Install Supabase Client**

```bash
# From backend directory with venv activated
pip install supabase

# Update requirements.txt
pip freeze > requirements.txt
```

### **1E: Test Backend**

```bash
# Start backend server
python app/main.py

# Should see:
# INFO:     Uvicorn running on http://0.0.0.0:8000

# Test in browser:
# http://localhost:8000/docs
# Should see new endpoints:
# - GET /api/v1/signals
# - GET /api/v1/signals/stats
```

---

## 🎨 **STEP 2: INSTALL FRONTEND**

### **2A: Create Signals Page**

```bash
# From frontend directory
cd frontend

# Create signals directory
mkdir -p app/signals

# Copy signals-page.tsx to app/signals/page.tsx
cp path/to/signals-page.tsx app/signals/page.tsx
```

### **2B: Test Frontend**

```bash
# Make sure frontend is running
npm run dev

# Visit: http://localhost:3000/signals
```

---

## ✅ **STEP 3: VERIFY EVERYTHING WORKS**

### **Backend Checklist:**
```
□ signals.py in backend/app/api/
□ main.py updated
□ supabase client installed
□ Backend running (python app/main.py)
□ /docs shows new endpoints
□ Can call /api/v1/signals/stats
```

### **Frontend Checklist:**
```
□ page.tsx in frontend/app/signals/
□ Frontend running (npm run dev)
□ /signals page loads
□ KPI cards show numbers
□ Table displays data
□ Search works
□ Filters work
□ Can select rows
□ Export CSV works
```

---

## 🧪 **STEP 4: TEST WITH REAL DATA**

### **If You Have Data in pv_cases:**

1. Visit `/signals`
2. You should see real data from your database
3. Try searching for a drug name
4. Try filtering by priority
5. Select some rows and export to CSV

### **If pv_cases Table is Empty:**

Let's create some test data:

```sql
-- Run this in Supabase SQL Editor

INSERT INTO pv_cases (
  drug_name,
  reaction,
  prr,
  case_count,
  priority,
  serious,
  dataset,
  organization_id
) VALUES
  ('Aspirin', 'Gastrointestinal bleeding', 12.5, 1284, 'critical', true, 'faers', 'org_1'),
  ('Warfarin', 'Hemorrhage', 8.3, 892, 'high', true, 'faers', 'org_1'),
  ('Ibuprofen', 'Gastric ulcer', 6.1, 654, 'high', true, 'faers', 'org_1'),
  ('Acetaminophen', 'Liver damage', 4.2, 423, 'medium', true, 'faers', 'org_1'),
  ('Lisinopril', 'Angioedema', 5.8, 345, 'medium', true, 'faers', 'org_1'),
  ('Metformin', 'Lactic acidosis', 3.2, 267, 'medium', false, 'faers', 'org_1'),
  ('Simvastatin', 'Rhabdomyolysis', 7.4, 543, 'high', true, 'faers', 'org_1'),
  ('Omeprazole', 'C. difficile infection', 4.9, 398, 'medium', true, 'faers', 'org_1'),
  ('Amoxicillin', 'Allergic reaction', 2.1, 876, 'low', false, 'faers', 'org_1'),
  ('Levothyroxine', 'Cardiac arrhythmia', 3.5, 234, 'low', false, 'faers', 'org_1');
```

After inserting, refresh `/signals` page - you should see the data!

---

## 🎯 **WHAT YOU SHOULD SEE**

### **Top Section (KPI Cards):**
```
┌─────────────┬─────────────┬─────────────┐
│ Total Cases │  Critical   │  Serious    │
│    10       │  Signals    │  Events     │
│   +12% ↑    │      1      │      8      │
│ vs last mo. │    +5% ↑    │    -3% ↓    │
└─────────────┴─────────────┴─────────────┘
```

### **Left Sidebar (Filters):**
```
Filters
──────
Dataset
[FAERS 2024 ▼]

Priority
☑ Critical
☑ High
☑ Medium
☐ Low

Serious Events
☐ Serious only
☐ Non-serious only

[Clear All Filters]
```

### **Main Content:**
```
Signals (10)              [Search drug or reaction...]

┌──────────────┬───────────────┬─────┬───────┬─────────┬─────────┐
│ Drug         │ Reaction      │ PRR │ Cases │ Priority│ Serious │
├──────────────┼───────────────┼─────┼───────┼─────────┼─────────┤
│ Aspirin      │ GI bleeding   │12.5 │ 1,284 │🔴Critical│  Yes   │
│ Warfarin     │ Hemorrhage    │ 8.3 │   892 │🟡High   │  Yes   │
│ Simvastatin  │ Rhabdomyolysis│ 7.4 │   543 │🟡High   │  Yes   │
│ ...          │               │     │       │         │         │
└──────────────┴───────────────┴─────┴───────┴─────────┴─────────┘

[Export (0)] [Generate Report]
```

---

## 🔄 **HOW IT WORKS**

### **Data Flow:**

```
1. User visits /signals
   ↓
2. Frontend fetches data
   fetch('http://localhost:8000/api/v1/signals')
   ↓
3. Backend queries Supabase
   SELECT * FROM pv_cases WHERE ...
   ↓
4. Backend returns JSON
   { signals: [...], total: 10 }
   ↓
5. Frontend displays in DataTable
   <DataTable data={signals} />
```

### **Search Flow:**

```
1. User types "Aspirin" in search
   ↓
2. Frontend debounces 500ms
   ↓
3. Sends new API request with search param
   /api/v1/signals?search=Aspirin
   ↓
4. Backend filters results
   WHERE drug_name ILIKE '%Aspirin%'
   ↓
5. Table updates with filtered results
```

---

## 🐛 **TROUBLESHOOTING**

### **Problem: "Failed to fetch signals"**

**Check:**
1. Backend is running (`python app/main.py`)
2. Backend URL is correct (`http://localhost:8000`)
3. CORS is configured (already done in main.py)
4. Check browser console for errors (F12)

**Fix:**
```bash
# Restart backend
cd backend
source venv/bin/activate  # or .\venv\Scripts\Activate.ps1
python app/main.py
```

---

### **Problem: "No signals found"**

**Check:**
1. `pv_cases` table exists in Supabase
2. Table has data (run test data SQL above)
3. organization_id matches your user

**Fix:**
```sql
-- Check if table exists
SELECT * FROM pv_cases LIMIT 5;

-- If empty, insert test data (see above)
```

---

### **Problem: Backend error "Module 'supabase' not found"**

**Fix:**
```bash
cd backend
source venv/bin/activate
pip install supabase --break-system-packages
```

---

### **Problem: Frontend shows loading forever**

**Check:**
1. Backend is responding (visit http://localhost:8000/api/v1/signals/stats)
2. No CORS errors in browser console
3. API URL is correct in frontend code

**Fix:**
- Check browser console (F12) for exact error
- Make sure both frontend and backend are running

---

## 📊 **TESTING FEATURES**

### **1. Search**
- Type "Aspirin" → Should filter to aspirin rows
- Type "Bleeding" → Should show reactions with bleeding
- Clear search → Shows all results

### **2. Filters**
- Uncheck "Critical" → Critical signals disappear
- Check "Serious only" → Shows only serious events
- Change dataset → Filters by dataset

### **3. Selection & Export**
- Click checkboxes to select rows
- Click "Export" → Downloads CSV file
- Open CSV → Should have selected signals

### **4. Sorting**
- Click "PRR" column → Sorts by PRR
- Click again → Reverses sort
- Click "Drug" → Sorts alphabetically

---

## 🎉 **SUCCESS CRITERIA**

You'll know it works when:

- ✅ KPI cards show numbers
- ✅ Table displays signals
- ✅ Search filters results
- ✅ Checkboxes select rows
- ✅ Export downloads CSV
- ✅ All filters work
- ✅ No errors in console

---

## 💬 **REPORT BACK**

After installation:

**✅ "Week 3 complete! Signal Explorer working!"**

Or if stuck:

**❌ "Issue: [describe problem]"**

Include:
- What step you're on
- Error message (if any)
- Screenshot of browser console

---

## 🚀 **WHAT'S NEXT**

After Signal Explorer works:

**Week 4:** Add more features
- Command palette (Cmd+K) integration
- Signal detail view (modal)
- Bulk actions
- Real-time updates

**Week 5:** Dashboard screen
- Overview charts
- Recent activity
- Quick stats

---

## 📁 **FILE LOCATIONS SUMMARY**

```
aethersignal-v2/
├── backend/
│   └── app/
│       ├── main.py              ← Updated
│       └── api/
│           ├── __init__.py      ← New (empty)
│           └── signals.py       ← New
└── frontend/
    └── app/
        └── signals/
            └── page.tsx         ← New
```

---

**Install now and let me know when it's working!** 🚀

I'll be ready to help troubleshoot or add more features! 💪
