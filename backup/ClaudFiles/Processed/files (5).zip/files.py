from fastapi import APIRouter, UploadFile, File, HTTPException, BackgroundTasks
from typing import Optional, List
from pydantic import BaseModel
from datetime import datetime
import os
import uuid
from pathlib import Path
import anthropic
from supabase import create_client, Client

router = APIRouter(prefix="/api/v1/files", tags=["files"])

# Initialize services
supabase_url = os.getenv("SUPABASE_URL")
supabase_key = os.getenv("SUPABASE_SERVICE_KEY")
supabase: Client = create_client(supabase_url, supabase_key)

anthropic_client = anthropic.Anthropic(api_key=os.getenv("ANTHROPIC_API_KEY"))

# Supported file formats
SUPPORTED_FORMATS = {
    'pdf': ['.pdf'],
    'document': ['.doc', '.docx', '.txt', '.rtf'],
    'spreadsheet': ['.xls', '.xlsx', '.csv'],
    'email': ['.eml', '.msg'],
    'image': ['.jpg', '.jpeg', '.png', '.gif', '.bmp'],
    'audio': ['.mp3', '.wav', '.m4a'],
    'archive': ['.zip', '.rar', '.7z'],
    'xml': ['.xml'],
}


class FileUploadResponse(BaseModel):
    file_id: str
    filename: str
    file_type: str
    size: int
    status: str
    message: str


class ProcessingStatus(BaseModel):
    file_id: str
    status: str  # 'pending', 'processing', 'completed', 'failed'
    progress: int  # 0-100
    message: str
    cases_created: Optional[int] = None
    error: Optional[str] = None


@router.post("/upload", response_model=FileUploadResponse)
async def upload_file(
    background_tasks: BackgroundTasks,
    file: UploadFile = File(...),
):
    """
    Upload a file for processing
    Supports: PDF, Word, Excel, Email, Images, Audio, ZIP
    """
    
    # Validate file
    if not file.filename:
        raise HTTPException(status_code=400, detail="No filename provided")
    
    # Get file extension
    file_ext = Path(file.filename).suffix.lower()
    
    # Detect file type
    file_type = "unknown"
    for category, extensions in SUPPORTED_FORMATS.items():
        if file_ext in extensions:
            file_type = category
            break
    
    if file_type == "unknown":
        raise HTTPException(
            status_code=400,
            detail=f"Unsupported file format: {file_ext}"
        )
    
    # Generate unique file ID
    file_id = str(uuid.uuid4())
    
    # Create upload directory if it doesn't exist
    upload_dir = Path("uploads")
    upload_dir.mkdir(exist_ok=True)
    
    # Save file locally (temporary)
    file_path = upload_dir / f"{file_id}{file_ext}"
    
    try:
        contents = await file.read()
        with open(file_path, "wb") as f:
            f.write(contents)
        
        file_size = len(contents)
        
        # Store file metadata in database
        file_record = {
            "id": file_id,
            "filename": file.filename,
            "file_type": file_type,
            "file_path": str(file_path),
            "size": file_size,
            "status": "pending",
            "uploaded_at": datetime.utcnow().isoformat(),
        }
        
        supabase.table("uploaded_files").insert(file_record).execute()
        
        # Queue background processing
        background_tasks.add_task(process_file, file_id, str(file_path), file_type)
        
        return FileUploadResponse(
            file_id=file_id,
            filename=file.filename,
            file_type=file_type,
            size=file_size,
            status="pending",
            message=f"File uploaded successfully. Processing started.",
        )
    
    except Exception as e:
        # Cleanup on error
        if file_path.exists():
            file_path.unlink()
        raise HTTPException(status_code=500, detail=f"Upload failed: {str(e)}")


@router.get("/status/{file_id}", response_model=ProcessingStatus)
async def get_processing_status(file_id: str):
    """
    Get processing status for a file
    """
    
    try:
        result = supabase.table("uploaded_files").select("*").eq("id", file_id).execute()
        
        if not result.data:
            raise HTTPException(status_code=404, detail="File not found")
        
        file_data = result.data[0]
        
        return ProcessingStatus(
            file_id=file_id,
            status=file_data.get("status", "unknown"),
            progress=file_data.get("progress", 0),
            message=file_data.get("message", ""),
            cases_created=file_data.get("cases_created"),
            error=file_data.get("error"),
        )
    
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


async def process_file(file_id: str, file_path: str, file_type: str):
    """
    Background task to process uploaded file
    """
    
    try:
        # Update status to processing
        supabase.table("uploaded_files").update({
            "status": "processing",
            "progress": 10,
            "message": "Extracting content..."
        }).eq("id", file_id).execute()
        
        # Step 1: Extract content based on file type
        content = await extract_content(file_path, file_type)
        
        supabase.table("uploaded_files").update({
            "progress": 30,
            "message": "AI extracting entities..."
        }).eq("id", file_id).execute()
        
        # Step 2: AI entity extraction
        entities = await extract_entities_with_ai(content)
        
        supabase.table("uploaded_files").update({
            "progress": 60,
            "message": "Creating cases..."
        }).eq("id", file_id).execute()
        
        # Step 3: Create cases
        cases_created = await create_cases_from_entities(entities, file_id)
        
        supabase.table("uploaded_files").update({
            "progress": 90,
            "message": "Auto-coding..."
        }).eq("id", file_id).execute()
        
        # Step 4: Auto-code cases
        await auto_code_cases(cases_created)
        
        # Mark as completed
        supabase.table("uploaded_files").update({
            "status": "completed",
            "progress": 100,
            "message": f"Successfully processed. {len(cases_created)} cases created.",
            "cases_created": len(cases_created)
        }).eq("id", file_id).execute()
        
    except Exception as e:
        # Mark as failed
        supabase.table("uploaded_files").update({
            "status": "failed",
            "error": str(e),
            "message": f"Processing failed: {str(e)}"
        }).eq("id", file_id).execute()


async def extract_content(file_path: str, file_type: str) -> str:
    """
    Extract text content from different file types
    """
    
    if file_type == "pdf":
        # PDF extraction
        import pdfplumber
        text = ""
        with pdfplumber.open(file_path) as pdf:
            for page in pdf.pages:
                text += page.extract_text() or ""
        return text
    
    elif file_type == "document":
        # Word document extraction
        from docx import Document
        doc = Document(file_path)
        text = "\n".join([para.text for para in doc.paragraphs])
        return text
    
    elif file_type == "spreadsheet":
        # Excel extraction
        import pandas as pd
        df = pd.read_excel(file_path)
        text = df.to_string()
        return text
    
    elif file_type == "email":
        # Email extraction
        import email
        with open(file_path, 'r') as f:
            msg = email.message_from_file(f)
            text = f"From: {msg['from']}\nSubject: {msg['subject']}\n\n{msg.get_payload()}"
        return text
    
    elif file_type == "image":
        # OCR for images
        import pytesseract
        from PIL import Image
        img = Image.open(file_path)
        text = pytesseract.image_to_string(img)
        return text
    
    else:
        # Fallback: try reading as text
        with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
            return f.read()


async def extract_entities_with_ai(content: str) -> List[dict]:
    """
    Use Claude to extract pharmacovigilance entities from text
    """
    
    prompt = f"""
You are a pharmacovigilance expert. Extract adverse event case information from the following text.

Text:
{content}

Extract the following information for each adverse event case found:
- Patient demographics (age, sex, weight)
- Drug information (name, dose, route, frequency, start date, stop date)
- Adverse reactions (description, onset date, severity, outcome)
- Reporter information (type, country)
- Causality assessment
- Seriousness (is it a serious adverse event?)

Return ONLY a JSON array of cases. Each case should have this structure:
{{
  "patient": {{
    "age": "number or null",
    "sex": "M/F/Unknown",
    "weight": "number or null"
  }},
  "drug": {{
    "name": "drug name",
    "dose": "dose string",
    "route": "oral/IV/etc",
    "frequency": "frequency",
    "start_date": "YYYY-MM-DD or null",
    "stop_date": "YYYY-MM-DD or null"
  }},
  "reaction": {{
    "description": "reaction description",
    "onset_date": "YYYY-MM-DD or null",
    "severity": "mild/moderate/severe",
    "outcome": "recovered/recovering/fatal/unknown"
  }},
  "serious": true/false,
  "narrative": "brief case narrative"
}}

If no adverse events found, return empty array [].
"""
    
    try:
        message = anthropic_client.messages.create(
            model="claude-sonnet-4-20250514",
            max_tokens=4000,
            messages=[
                {"role": "user", "content": prompt}
            ]
        )
        
        # Parse JSON response
        import json
        response_text = message.content[0].text
        
        # Extract JSON from response (handle markdown code blocks)
        if "```json" in response_text:
            json_str = response_text.split("```json")[1].split("```")[0].strip()
        elif "```" in response_text:
            json_str = response_text.split("```")[1].split("```")[0].strip()
        else:
            json_str = response_text.strip()
        
        entities = json.loads(json_str)
        
        return entities if isinstance(entities, list) else [entities]
    
    except Exception as e:
        print(f"AI extraction error: {e}")
        return []


async def create_cases_from_entities(entities: List[dict], file_id: str) -> List[str]:
    """
    Create pv_cases records from extracted entities
    """
    
    case_ids = []
    
    for entity in entities:
        try:
            # Generate PRR (mock for now - would be calculated from historical data)
            import random
            prr = round(random.uniform(1.5, 15.0), 1)
            
            # Determine priority based on seriousness and PRR
            serious = entity.get("serious", False)
            if serious and prr > 10:
                priority = "critical"
            elif serious or prr > 5:
                priority = "high"
            elif prr > 2:
                priority = "medium"
            else:
                priority = "low"
            
            case_data = {
                "drug_name": entity.get("drug", {}).get("name", "Unknown"),
                "reaction": entity.get("reaction", {}).get("description", "Unknown"),
                "prr": prr,
                "case_count": 1,
                "priority": priority,
                "serious": serious,
                "dataset": "uploaded",
                "organization_id": "org_1",  # Would come from auth
                "source_file_id": file_id,
                "narrative": entity.get("narrative", ""),
                "patient_age": entity.get("patient", {}).get("age"),
                "patient_sex": entity.get("patient", {}).get("sex"),
            }
            
            result = supabase.table("pv_cases").insert(case_data).execute()
            
            if result.data:
                case_ids.append(result.data[0]["id"])
        
        except Exception as e:
            print(f"Error creating case: {e}")
            continue
    
    return case_ids


async def auto_code_cases(case_ids: List[str]):
    """
    Auto-code cases with MedDRA terms using AI
    """
    
    # For now, this is a placeholder
    # In production, you'd:
    # 1. Use MedDRA API or database
    # 2. Or use AI to suggest MedDRA codes
    # 3. Store in separate coding table
    
    pass
