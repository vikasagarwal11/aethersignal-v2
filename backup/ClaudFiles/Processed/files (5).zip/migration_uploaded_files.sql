-- Migration: Add uploaded_files table
-- This tracks file uploads and processing status

CREATE TABLE IF NOT EXISTS uploaded_files (
    id TEXT PRIMARY KEY,
    filename TEXT NOT NULL,
    file_type TEXT NOT NULL,
    file_path TEXT NOT NULL,
    size INTEGER NOT NULL,
    status TEXT NOT NULL DEFAULT 'pending', -- pending, processing, completed, failed
    progress INTEGER DEFAULT 0, -- 0-100
    message TEXT,
    cases_created INTEGER,
    error TEXT,
    organization_id TEXT,
    uploaded_by TEXT,
    uploaded_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    processed_at TIMESTAMP WITH TIME ZONE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- Add source_file_id to pv_cases to track which file created the case
ALTER TABLE pv_cases 
ADD COLUMN IF NOT EXISTS source_file_id TEXT REFERENCES uploaded_files(id);

-- Add narrative and patient fields to pv_cases
ALTER TABLE pv_cases 
ADD COLUMN IF NOT EXISTS narrative TEXT,
ADD COLUMN IF NOT EXISTS patient_age INTEGER,
ADD COLUMN IF NOT EXISTS patient_sex TEXT;

-- Indexes for performance
CREATE INDEX IF NOT EXISTS idx_uploaded_files_status ON uploaded_files(status);
CREATE INDEX IF NOT EXISTS idx_uploaded_files_org ON uploaded_files(organization_id);
CREATE INDEX IF NOT EXISTS idx_pv_cases_source_file ON pv_cases(source_file_id);

-- Function to update updated_at timestamp
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = CURRENT_TIMESTAMP;
    RETURN NEW;
END;
$$ language 'plpgsql';

-- Trigger for uploaded_files
CREATE TRIGGER update_uploaded_files_updated_at BEFORE UPDATE
    ON uploaded_files FOR EACH ROW
    EXECUTE PROCEDURE update_updated_at_column();

COMMENT ON TABLE uploaded_files IS 'Tracks uploaded files and their processing status';
COMMENT ON COLUMN uploaded_files.status IS 'File processing status: pending, processing, completed, failed';
COMMENT ON COLUMN uploaded_files.progress IS 'Processing progress from 0-100';
COMMENT ON COLUMN uploaded_files.cases_created IS 'Number of pv_cases created from this file';
