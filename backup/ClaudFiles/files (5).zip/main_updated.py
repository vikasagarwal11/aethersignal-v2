from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
import sentry_sdk
import os
from dotenv import load_dotenv

# Import routers
from app.api.signals import router as signals_router
from app.api.files import router as files_router

load_dotenv()

# Initialize Sentry
sentry_sdk.init(
    dsn=os.getenv("SENTRY_DSN"),
    traces_sample_rate=1.0,
    environment=os.getenv("ENVIRONMENT", "development"),
)

app = FastAPI(
    title="AetherSignal V2 API",
    description="AI-Powered Pharmacovigilance Platform",
    version="2.0.0",
)

# CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=[
        "http://localhost:3000",
        "http://localhost:3001",
        "https://aethersignal.vercel.app",  # Production frontend
    ],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Include routers
app.include_router(signals_router)
app.include_router(files_router)


@app.get("/")
async def root():
    return {
        "message": "AetherSignal V2 API",
        "version": "2.0.0",
        "status": "running",
        "features": [
            "Signal Detection",
            "Universal File Processing",
            "AI Entity Extraction",
            "Auto-Coding",
        ],
    }


@app.get("/health")
async def health():
    return {"status": "healthy", "ai": "enabled"}


if __name__ == "__main__":
    import uvicorn
    import sys
    from pathlib import Path

    # Add backend directory to Python path for uvicorn reloader
    backend_dir = Path(__file__).parent.parent
    if str(backend_dir) not in sys.path:
        sys.path.insert(0, str(backend_dir))

    uvicorn.run("app.main:app", host="0.0.0.0", port=8000, reload=True)
